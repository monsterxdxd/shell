#!/bin/bash
# set n to 1
n=1

if `test n -eq *`

then
		echo "Incorrecto, Usa $n + parametros"
	
fi

# Poner palabra Hello delante cualquier parametro
for n in $*
	do
		echo "Hello $h";
	done;

# continue until $n equals 5
while [ $n -le 10 ]

do
	echo "Welcome $n times."
	n=$(( n+1 ))	 # increments $n

done;

for n in $*
do
	echo "Welcome $n times."
	n=$(( n+1 ))	 # increments $n

done;
