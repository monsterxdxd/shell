#!/bin/bash
n=1
echo “Ingresa un número y presiona ENTER”
read M
#El ciclo controla que n sea menor o igual a 10
while [ $n -le 10 ]
do
 #En R almacenamos la multiplicación de n por M
 R=$[n*M]
 #Se imprime dicha multiplicación en pantalla
 echo “$M * $n= $R”
 #Con let, incrementamos el valor de n en 1 unidad
 let n=$n+1
done

exit;
